# Program 1: Closest and Farthest Hamming Pairs
# Input:  data_mem[0..63]  (MSB at even addr, LSB at odd addr)
# Output: data_mem[64] = min Hamming dist, data_mem[65] = max Hamming dist
#
# Registers:
#   R0=0 (hardwired), R1=min, R2=max, R3=i, R4=j
#   R5=XOR result/scratch addr/total dist
#   R6=popcount accumulator/temp addr (32 preserved after j check)
#   R7=constant 1 (bitmask, never overwritten)
#
# Scratch: mem[200] = MSB popcount temp
#   Address 200 built as: ldi 13; shf 4; addi -8 = 200
#
# Design notes:
#   - JMP is ABSOLUTE: jmp rN → PC = rN
#   - jmpl LABEL rN is a 5-instruction pseudo-op (load addr + jmp)
#   - Requires 10-bit PC (>256 instruction slots)
#   - MIN update uses forward bcs to TRAMPOLINE_MIN (+29 offset, within +31)
#   - INNER loop back-branch: jmpl inlined in j-control fall-through
#   - After j==32 exit, R6=32 is preserved into i-control (no rebuild needed)

# ─── INIT (addr 0–8) ────────────────────────────────────────────────────────
    ldi 1
    sto r7          # R7 = 1  (constant bitmask, never changed)

    ldi 15
    addi 1
    sto r1          # R1 = 16  (min init: max possible Hamming distance)

    ldi 0
    sto r2          # R2 = 0   (max init)

    ldi 0
    sto r3          # R3 = 0   (i = 0)

# ─── OUTER LOOP (addr 9–11) ─────────────────────────────────────────────────
OUTER_LOOP:
    mov r3
    addi 1
    sto r4          # R4 = j = i + 1

# ─── INNER LOOP (addr 12–133) ───────────────────────────────────────────────
INNER_LOOP:

    # Load MSB_j = mem[2*j]
    mov r4
    shf 1           # 2*j
    sto r6
    ld  r6          # ACC = MSB_j
    sto r5          # R5 = MSB_j

    # Load MSB_i = mem[2*i], XOR with MSB_j
    mov r3
    shf 1           # 2*i
    sto r6
    ld  r6          # ACC = MSB_i
    xor r5          # ACC = MSB_i XOR MSB_j
    sto r5          # R5 = MSB XOR

    # Popcount MSB XOR → R6  (unrolled 8 bits)
    ldi 0
    sto r6

    mov r5
    and r7
    add r6
    sto r6          # bit 0

    mov r5
    shf -1
    and r7
    add r6
    sto r6          # bit 1

    mov r5
    shf -2
    and r7
    add r6
    sto r6          # bit 2

    mov r5
    shf -3
    and r7
    add r6
    sto r6          # bit 3

    mov r5
    shf -4
    and r7
    add r6
    sto r6          # bit 4

    mov r5
    shf -5
    and r7
    add r6
    sto r6          # bit 5

    mov r5
    shf -6
    and r7
    add r6
    sto r6          # bit 6

    mov r5
    shf -7
    and r7
    add r6
    sto r6          # bit 7  → R6 = popcount(MSB XOR)

    # Save MSB popcount to mem[200]
    ldi 13
    shf 4
    addi -8         # ACC = 200
    sto r5          # R5 = 200 (scratch address)
    mov r6          # ACC = MSB popcount
    st  r5          # mem[200] = MSB popcount

    # Load LSB_j = mem[2*j+1]
    mov r4
    shf 1
    addi 1          # 2*j+1
    sto r6
    ld  r6          # ACC = LSB_j
    sto r5          # R5 = LSB_j

    # Load LSB_i = mem[2*i+1], XOR with LSB_j
    mov r3
    shf 1
    addi 1          # 2*i+1
    sto r6
    ld  r6          # ACC = LSB_i
    xor r5          # ACC = LSB XOR
    sto r5          # R5 = LSB XOR

    # Popcount LSB XOR → R6  (unrolled 8 bits)
    ldi 0
    sto r6

    mov r5
    and r7
    add r6
    sto r6

    mov r5
    shf -1
    and r7
    add r6
    sto r6

    mov r5
    shf -2
    and r7
    add r6
    sto r6

    mov r5
    shf -3
    and r7
    add r6
    sto r6

    mov r5
    shf -4
    and r7
    add r6
    sto r6

    mov r5
    shf -5
    and r7
    add r6
    sto r6

    mov r5
    shf -6
    and r7
    add r6
    sto r6

    mov r5
    shf -7
    and r7
    add r6
    sto r6          # R6 = popcount(LSB XOR)

    # Total dist = MSB_popcount + LSB_popcount → R5
    ldi 13
    shf 4
    addi -8         # ACC = 200
    sto r5
    ld  r5          # ACC = MSB popcount
    add r6          # ACC = total Hamming dist
    sto r5          # R5 = total dist

    # ── MIN CHECK ───────────────────────────────────────────────────────────
    # cmp r1: ACC(dist) - R1(min); carry=1 if dist < min → update min
    mov r5
    cmp r1
    bcs TRAMPOLINE_MIN  # dist < min: forward branch (+29, within +31)

    # dist >= min: fall through to MAX_CHECK

# ─── MAX CHECK (after inner loop body) ──────────────────────────────────────
MAX_CHECK:
    # cmp r2: ACC(dist) - R2(max); carry=1 if dist < max → skip update
    mov r5
    cmp r2
    bcs SKIP_MAX    # dist < max: skip
    beq SKIP_MAX    # dist == max: skip
    # dist > max: update
    mov r5
    sto r2          # R2 = dist (new max)

SKIP_MAX:
    # ── J LOOP CONTROL ──────────────────────────────────────────────────────
    # j++, compare to 32; if j < 32: loop back (via inline jmpl)
    mov r4
    addi 1
    sto r4          # j++

    ldi 8
    shf 2
    sto r6          # R6 = 32

    mov r4
    cmp r6          # j - 32: carry=1 if j < 32
    bcs INNER_LOOP_BACK    # j < 32: fall into inline jmpl (+2 forward)
    beq SKIP_INNER_AFTER   # j == 32: skip jmpl, go to i control (+6 forward)

INNER_LOOP_BACK:
    jmpl INNER_LOOP r6     # 5 instrs: absolute jump to INNER_LOOP

    # ── I LOOP CONTROL ──────────────────────────────────────────────────────
    # Reached only when j==32 (via beq above). R6=32 preserved from j check.
SKIP_INNER_AFTER:
    mov r3
    addi 1
    sto r3          # i++

    mov r3
    cmp r6          # i - 32 (R6=32 still valid from j check above)
    bcs OUTER_LOOP_BACK    # i < 32: forward to OUTER_LOOP_BACK jmpl
    beq STORE_RESULTS      # i == 32: forward to store results

# ─── TRAMPOLINE: forward branch target for min update ────────────────────────
# Placed here so bcs TRAMPOLINE_MIN offset = +29 (within +31 limit)
# Normal execution never falls through here (done by beq STORE_RESULTS above)
TRAMPOLINE_MIN:
    jmpl DO_MIN_UPDATE r6  # 5 instrs: absolute jump to DO_MIN_UPDATE

# ─── OUTER LOOP BACK ────────────────────────────────────────────────────────
OUTER_LOOP_BACK:
    jmpl OUTER_LOOP r6     # 5 instrs: absolute jump to OUTER_LOOP

# ─── STORE RESULTS ──────────────────────────────────────────────────────────
STORE_RESULTS:
    ldi 8
    shf 3           # ACC = 64
    sto r6
    mov r1
    st  r6          # mem[64] = min

    mov r6
    addi 1
    sto r6          # R6 = 65
    mov r2
    st  r6          # mem[65] = max

    done            # assert done signal to testbench

# ─── MIN UPDATE BLOCK ───────────────────────────────────────────────────────
# Reached via TRAMPOLINE_MIN when dist < min.
# After updating min, jumps to MAX_CHECK to continue comparison.
DO_MIN_UPDATE:
    mov r5
    sto r1          # R1 = dist (new min)
    jmpl MAX_CHECK r6      # 5 instrs: absolute jump to MAX_CHECK
